/**
 * Access to video devices
 */
/**
 * @author andy
 *
 */
package lejos.hardware.video;