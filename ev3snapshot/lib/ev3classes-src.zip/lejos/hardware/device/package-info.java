/**
 * Support for EV3 third-party devices
 *
 */
package lejos.hardware.device;