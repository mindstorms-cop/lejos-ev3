/**
 * Emulation of RCX communication classes
 */
package lejos.remote.rcx;
