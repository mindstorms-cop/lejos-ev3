package lejos.remote.ev3;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class RemoteRequestI2CPort extends RemoteRequestIOPort {

	public RemoteRequestI2CPort(ObjectInputStream is, ObjectOutputStream os) {
		// TODO Auto-generated constructor stub
	}

}
