package lejos.remote.ev3;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class RemoteRequestUARTPort extends RemoteRequestIOPort {

	public RemoteRequestUARTPort(ObjectInputStream is, ObjectOutputStream os) {
		// TODO Auto-generated constructor stub
	}

}
