package lejos.remote.ev3;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class RemoteRequestMotorPort extends RemoteRequestIOPort {

	public RemoteRequestMotorPort(ObjectInputStream is, ObjectOutputStream os) {
		// TODO Auto-generated constructor stub
	}

}
