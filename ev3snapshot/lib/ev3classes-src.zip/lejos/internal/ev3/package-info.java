/**
 * EV3-specific implementations that are not part of the published API.
 */
package lejos.internal.ev3;