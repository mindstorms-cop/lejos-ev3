/**
 * Geometric shape support for robotics using float co-ordinates
 */
package lejos.robotics.geometry;
