/**
 * Support for maps
 */
package lejos.robotics.mapping;
